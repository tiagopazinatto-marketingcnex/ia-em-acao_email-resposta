# IA em Ação · e-mails

E-mails HTML do IA em Ação (CNEX), hospedados via GitHub Pages para importação no RD Station ("Importar HTML" → URL do e-mail).

## URLs para importar no RD

| E-mail | URL |
|---|---|
| Convite (sem saudação) — **usar este** | https://tiagopazinatto-marketingcnex.github.io/ia-em-acao_email-resposta/email/convite-ia-em-acao-com-email.html |
| Convite (com saudação por nome) | https://tiagopazinatto-marketingcnex.github.io/ia-em-acao_email-resposta/email/convite-ia-em-acao-com-email-nome.html |
| Confirmação do formulário da LP | https://tiagopazinatto-marketingcnex.github.io/ia-em-acao_email-resposta/email/confirmacao-ia-em-acao.html |

## Assuntos

- Convite: Quantas vezes você já ouviu "precisamos avançar em IA"?
- Confirmação: Recebemos seu contato sobre o IA em Ação

## Imagens

Todas em `email/`, referenciadas por URL absoluta do GitHub Pages. Se o repositório ou o usuário mudar de nome, as URLs dentro dos HTMLs precisam ser atualizadas.
